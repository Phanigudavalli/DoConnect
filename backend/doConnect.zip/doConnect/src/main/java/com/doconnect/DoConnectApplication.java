package com.doconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoConnectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoConnectApplication.class, args);
	}

}
